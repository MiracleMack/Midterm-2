"""Traceability enforcement (pipeline stages 5-8).
Author: Mack Miracle (CPS 310 Fall 2026, Midterm #2)

Usage: python trace_check.py <project-root> <ontology.ttl> <trace.csv>

Fails (exit 1) when:
  - a requirement in trace.csv names an ontology term that does not exist,
  - a code or test file named in trace.csv does not exist under the project root,
  - a '# zs: <Rule>' tag in the project's code or tests names a rule that is not in the ontology (orphan tag),
  - an ontology rule is not referenced by any requirement (uncovered rule).
"""
import csv, re, sys
from pathlib import Path
import rdflib
from rdflib import RDF

ZS = rdflib.Namespace("http://example.org/zombie-sim#")
TAG = re.compile(r"#\s*zs:\s*(R_\w+)")


def load(root, onto, trace):
    g = rdflib.Graph(); g.parse(onto, format="turtle")
    rules = {str(s).split("#")[1] for s in g.subjects(RDF.type, ZS.Rule)}
    terms = {str(s).split("#")[1] for s in set(g.subjects()) if str(s).startswith(str(ZS))}
    rows = list(csv.DictReader(open(trace)))
    return g, rules, terms, rows


def split(cell):
    return [x for x in (cell or "").split(";") if x]


def scan_tags(root):
    tags = {}
    for sub in ("src", "tests", "utils", "runtime"):
        for f in (root / sub).glob("**/*.py"):
            if "__pycache__" in f.parts:
                continue
            for m in TAG.finditer(f.read_text(errors="ignore")):
                tags.setdefault(m.group(1), set()).add(str(f.relative_to(root)))
    return tags


def main():
    root, onto, trace = Path(sys.argv[1]).resolve(), Path(sys.argv[2]), Path(sys.argv[3])
    g, rules, terms, rows = load(root, onto, trace)
    fails = []
    for r in rows:
        for t in split(r["ontology_terms"]):
            if t not in terms:
                fails.append(f"{r['requirement']}: ontology term '{t}' does not exist")
        for f in split(r["code"]) + split(r["tests"]):
            if not (root / f).exists():
                fails.append(f"{r['requirement']}: file '{f}' does not exist")
    for tag, files in scan_tags(root).items():
        if tag not in rules:
            fails.append(f"orphan tag '# zs: {tag}' in {sorted(files)}: not a rule in the ontology")
    used = {t for r in rows for t in split(r["ontology_terms"])}
    for rule in sorted(rules - used):
        fails.append(f"uncovered rule: {rule} is referenced by no requirement")
    for f in fails:
        print("FAIL", f)
    print(f"\n{len(rows)} requirements, {len(rules)} rules, {len(fails)} trace failure(s)")
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
