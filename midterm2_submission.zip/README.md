# Ontology-Controlled Pipeline for AI-Driven Development of the Zombie Game

**Author:** Mack Miracle
**Course:** CPS 310, Fall 2026, Midterm #2 (individual work)

This package contains a process control pipeline for developing the Zombie Game Simulation with an AI model, built around a formal ontology. The full design, the argument for what it controls, all prompts and the demo results are in **`PIPELINE.md`**. Start there.

## Contents

| Path | What it is |
|---|---|
| `PIPELINE.md` | the pipeline: stages, controls, argument, prompts, demo results, limitations |
| `requirements.md` | stage 1: requirements R1-R14 |
| `zombie_ontology.ttl` | stage 2: the ontology (Turtle/OWL) |
| `trace.csv` | requirement -> ontology terms -> code files -> test files |
| `validate_ontology.py` | stage 3: ontology validation |
| `trace_check.py`, `coverage.py` | stages 5, 6, 8: trace enforcement and coverage metrics |
| `ontology_check.py` | stage 7: checks code against the ontology |
| `gate.py`, `approvals.json` | approval gates and the recorded approvals (stages 1, 2, 3, 4, 5, 9) |
| `demo/` | the four main demo runs (naive x3, pipeline), five repeat naive runs, a repair-loop run and an independent Copilot run of the pipeline's code and test stages with prompts, outputs and reports; see `demo/README.md` |

The game's own source code is not duplicated here. The demo runs change only `src/mutation.py`, `src/zombie.py` and `tests/test_mutation.py` of the project snapshot dated 14 Nov 2026.

## Running the scripts
Requires Python 3 with `rdflib` (`pip install rdflib`). The checks that run against a project also need the project folder; see `demo/README.md` for how to reproduce a run.
```
python validate_ontology.py zombie_ontology.ttl
python gate.py verify
```
`gate.py verify` should list all six approvals as VALID. Changing an approved file (for example `requirements.md` or `zombie_ontology.ttl`) voids its approval by design.
