# Ontology-Controlled Pipeline for AI-Driven Development of the Zombie Game Simulation

CPS 310 - Fall 2026 - Midterm #2
Name: Mack Miracle

---

## 1. Purpose and Scope

This document defines a process control pipeline for developing the Zombie Game Simulation with an AI model.

**A formal ontology is the center of the process. It acts not as a guide, but as a control that dictates the process an AI must follow as it develops.** The ontology (a machine-readable model of the game's entities, relationships and rules) dictates the process in four ways:
1. **It fixes the vocabulary and numbers.** The AI may use only the entities, attributes and rule parameters the ontology defines, and anything else is a defect (stages 4, 5, 7).
2. **It decides when a stage is finished.** A stage is complete only when its output maps fully to ontology terms, so completeness is measured against the ontology, not judged by feel (coverage metrics, Section 2).
3. **It determines where a failure goes.** Every violation names the ontology rule it breaks, and that rule decides which stage must be redone (stage 9).
4. **It cannot be bypassed.** No stage starts until the previous stage is approved against it, and changing an approved artifact voids its approval (Section 4).

These controls are enforced by five scripts, so a stage can fail mechanically and does not rely on anyone remembering to check: `validate_ontology.py` (stage 3), `trace_check.py` and `coverage.py` (stages 5, 6 and 8), `ontology_check.py` (stage 7) and `gate.py` (every approval gate). The AI generates and the author reviews and signs. Section 10 states what the scripts cannot do.

The problem: when an AI is simply asked to "add a feature to the zombie game", it produces plausible code that silently drifts from the intended design. It renames things between prompts, invents attributes and mechanics, uses different numbers for the same rule in different modules, forgets requirements, and breaks old rules when new ones are added. The pipeline is designed so these failures are detected, traced to a cause, and repaired in the right place.

The pipeline is applied to the existing simulation (agent-based, tick-stepped, seeded, sector-parallel), described by the project's `README.md`.

---

## 2. The Four Controls Applied at Every Stage

| Control | Meaning | How it is carried out |
|---|---|---|
| **Ontology reasoning** | The stage's output is checked for logical consistency against the ontology, and consequences are derived. Example: an agent cannot be both Human and Zombie, and every rule must have its parameters. | a reasoning prompt (R1, Section 7), plus the script `validate_ontology.py` at stage 3 and the executed rule checks of `ontology_check.py` at stage 7 |
| **Coverage metrics** | Completeness is stated as numbers: requirements mapped, rules designed, rules implemented, rules tested. | `coverage.py`: the percentage of requirements with an ontology term, code and a test. New requirements must reach 100% on all three. |
| **Traceability enforcement** | Every item links to what justifies it, in both directions. An item with no link is a defect. | `trace.csv` (requirement, ontology terms, code files, test files) checked by `trace_check.py`, plus tags in code and tests (`# zs: R_Mutation`). It fails on unknown terms, missing files, orphan tags and ontology rules that no requirement uses. |
| **Formal approval gate** | The stage's output is reviewed against its gate conditions and approved in writing. Any later change to the output invalidates the approval. | `gate.py`: `approve` records the author and a SHA-256 hash of each artifact in `approvals.json`; `require <stage>` blocks the next stage unless that approval exists and no artifact has changed since |

Every script returns a pass or fail exit code. The AI-generated content (ontology additions, design, code, tests) is produced by the prompts in Section 7, and the author reviews it and signs the gate.

---

## 3. Pipeline Overview

```
 1 Game Requirements
        |
 2 Ontology Construction          <-- main human checkpoint
        |
 3 Ontology Validation
        |
 4 AI Design Generation
        |
 5 Design Compliance Check
        |
 6 AI Code Generation (one module per prompt)
        |
 7 Ontology-Based Verification
        |
 8 Testing
        |
 9 Results / Revision Loop  --> returns to the stage that owns the fault
```

| # | Stage | Input | Output | Reasoning | Coverage (required) | Trace link enforced | Gate |
|---|---|---|---|---|---|---|---|
| 1 | Game Requirements | feature idea | `requirements.md` | each item is one testable statement | all items have IDs | none (origin) | author approves |
| 2 | Ontology Construction | requirements, code | `zombie_ontology.ttl` | proposed changes checked for contradictions (P1, R1) | 100% of requirements map to a term | requirement -> term | author approves (main checkpoint) |
| 3 | Ontology Validation | ontology | validation report | `validate_ontology.py`: parses, disjointness, rule parameters, competency questions | 100% of rules have parameters | none | script passes, author confirms |
| 4 | AI Design Generation | ontology, requirements | `design.md` | only ontology terms used (P2) | 100% of rules appear in design | term -> design element | author approves |
| 5 | Design Compliance Check | design, ontology | trace and coverage tables | every design element checked against the ontology (P3) | 0 orphans, 0 uncovered rules | design <-> term, both directions | author approves |
| 6 | AI Code Generation | design, ontology slice | source files | module checked against its ontology slice (P4) | 100% of rules have code | design -> code tags | files import |
| 7 | Ontology-Based Verification | code, ontology | checker report | `ontology_check.py`: structure and executed rules | every rule has an executed check | code tags valid | 0 violations |
| 8 | Testing | code, invariants | test report | tests derived from ontology rules (P5) | 100% of rules have a test | rule -> test | all pass, no regressions |
| 9 | Results / Revision Loop | failure reports | repaired artifact | failure routed by rule (P6) | metrics recorded per round | log per round | author approves release |

---

## 4. Approval Record

Every gate produces one row, and the row is recorded by `gate.py`, not typed by hand:

```
python gate.py approve <stage> --by "Name" <artifact files>   # stores the author, the date and a SHA-256 hash of each file
python gate.py require <stage>                                # run before the next stage: fails if the approval is missing or any file changed
python gate.py verify                                         # lists every approval and marks changed ones VOID
```

A later change to an approved artifact changes its hash, which voids the approval, and the stage must be approved again before the pipeline continues. `demo/gate_demo.txt` shows this on a throwaway file: blocked before approval, allowed after, blocked again after an edit.

| Stage | Artifact and version | Checks passed | Coverage | Approved by | Date | Notes |
|---|---|---|---|---|---|---|
| (one row per stage per round) | | | | | | |

---

## 5. Stage Design

### Stage 1 - Game Requirements
Requirements are written as single testable statements with IDs (`requirements.md`) before any AI is involved. Each is marked as already implemented (E) or new (N).
**Why:** the AI cannot drift from an intent that was never written down, and the IDs are the root of the traceability chain.

### Stage 2 - Ontology Construction
The AI proposes ontology changes from the requirements and the existing code (P1). The author approves them. The ontology keeps three kinds of knowledge apart: **entities** (Agent, Human, Zombie, Sector, Mutation), **relations** (memberOf, attacks, turnsInto, hasMutation), and **rules with numeric parameters** (R_RangeHuman and its numbers).
Reasoning example: the turning rule is modelled as a state change of one agent identity, linked by a Turning event, so that Human and Zombie remain disjoint classes without contradiction.
**Why a human checkpoint:** every later stage trusts the ontology, so an error here corrupts everything after it. It is the cheapest place to catch a mistake.

### Stage 3 - Ontology Validation
`validate_ontology.py` checks that the file parses, Human and Zombie are disjoint subclasses of Agent, each rule has its parameters, and competency questions can be answered by querying the ontology. A prompt-based reasoning pass (R1) asks the AI to look for contradictions and gaps.
**Why:** an incomplete or inconsistent ontology must never reach the AI.

### Stage 4 - AI Design Generation
The AI designs modules using only ontology terms (P2). Needed terms that do not exist are listed under "ONTOLOGY GAPS" and are not designed around.
**Why:** restricting the vocabulary prevents invented entities and mechanics where they are cheapest to fix.

### Stage 5 - Design Compliance Check
The AI produces two tables (P3): each design element to its ontology term (orphans flagged), and each ontology rule to the design element that implements it (uncovered rules flagged). `trace_check.py` then verifies the requirement-to-term-to-code-to-test links in `trace.csv` and `coverage.py` computes the coverage percentages. The author reviews and approves.
**Why:** it exposes both invention and omission before any code exists.

### Stage 6 - AI Code Generation
Code is generated one module at a time (P4). Each prompt contains only the ontology slice for that module and the interfaces of modules it depends on. The AI must tag the code with the rule it implements.
**Why:** small scoped prompts with the governing rules inline limit cross-module inconsistency and give the checker a narrow target.

### Stage 7 - Ontology-Based Verification
`ontology_check.py` runs two layers. The structural layer compares class attributes in the code against the ontology to find invented attributes. The behavioral layer imports the code and executes each rule using the ontology's own parameters (human range, hit chance, damage bounds, dead agents inert, turning keeps identity). Each failure names the rule it breaks.
**Why:** this is the hard gate of the pipeline. A rule that is violated blocks the stage.

### Stage 8 - Testing
Tests are derived from the ontology rules (P5), and the project's existing suite is run to detect regressions.
**Why:** the checker samples rule behavior, while tests cover the running simulation including seeded determinism.

### Stage 9 - Results / Revision Loop
A failure is routed to the stage that owns it:

| Failure type | Goes back to |
|---|---|
| Code violates a rule the ontology states correctly | Stage 6 (P6, with the rule name and violation text) |
| Code is right but the ontology is wrong or silent | Stage 2, then 3 onward |
| Design uses an unknown term | Stage 4 |
| Requirement is ambiguous | Stage 1 |

The loop runs at most **3 rounds** per failure. After that the author decides. The bound prevents endless AI retries.

---

## 6. What the Pipeline Controls, and Why

| Aspect | Failure in naive AI development | Control | Why it works |
|---|---|---|---|
| Vocabulary | entities renamed or reshaped between prompts | fixed ontology terms in every prompt, trace of every term | there is a named definition to copy, not to invent |
| Hallucinated attributes | fields and mechanics the game does not have | structural check (stage 7) and orphan check (stage 5) | an attribute outside the ontology is a mechanical failure, not a judgment |
| Rule consistency | the same rule has different constants in different modules | parameters stored once in the ontology and read by the checker | a number that differs from the ontology fails |
| Silent omission | a requirement is never implemented | coverage metrics and the requirement -> term -> design -> code -> test trace | an uncovered requirement is an empty cell |
| Regression | a new feature breaks an old rule | the checker and existing tests rerun every round | old rules are re-executed, not remembered |
| Unbounded rework | the AI keeps "fixing" without converging | routed revisions, 3-round limit, escalation | each failure is named, located and capped |
| Accountability | no record of why code looks the way it does | approval records and saved prompts | each decision has an artifact |

### Comparison with naive AI-driven development
A naive process is one prompt ("add zombie mutations to this game") followed by reading the result. It has no stated source of truth, so correctness is judged from the reviewer's memory. Rule drift is found only if the reviewer happens to notice it, and failures are fixed through free-form conversation with no record of which rule was broken. The demo (Section 8) measures both processes on the same task.

---

## 7. Prompts

All major prompts. `{...}` marks values filled in at run time.

**P1 - Ontology construction (stage 2)**
```
You are maintaining a formal ontology for a simulation game, written in OWL/Turtle.
Existing ontology:
{ontology_ttl}
Requirements to model:
{requirements}
Relevant existing code:
{code_excerpts}
Task: propose ONLY the additions or changes needed to represent these requirements.
Rules: (1) Model entities (classes, properties) separately from rules.
(2) Every numeric parameter of a rule must be stored as a data property on the rule.
(3) Do not remove existing terms. (4) For each addition, name the requirement ID it serves.
(5) If a requirement is ambiguous, list a question instead of guessing.
Output: a Turtle diff and a list of questions.
```

**R1 - Ontology reasoning (stages 2 and 3)**
```
Act as a reasoner over this ontology: {ontology_ttl}
1. List any logical contradiction (for example an individual that must belong to two disjoint classes).
2. List every rule that lacks a numeric parameter its requirement needs.
3. For each requirement below, state which ontology terms it depends on, or "NONE".
4. Answer these competency questions using only the ontology: {competency_questions}
Requirements: {requirements}
Output four numbered lists. Do not modify the ontology.
```

**P2 - Design generation (stage 4)**
```
Using ONLY the ontology below, design the modules needed to implement the requirements.
Ontology: {ontology_ttl}
Requirements: {requirements}
For each module give: name, responsibility, the ontology classes/properties/rules it uses,
and the modules it depends on. Do not introduce any entity, attribute or rule that is not
in the ontology. If something is needed that the ontology lacks, list it under
"ONTOLOGY GAPS" and do not design around it.
```

**P3 - Design compliance (stage 5)**
```
Ontology: {ontology_ttl}
Design: {design_md}
Requirements: {requirements}
Produce two tables.
(A) each design element -> the ontology term(s) it relies on; mark any element with no term ORPHAN.
(B) each ontology rule -> the design element that implements it; mark any rule with no element UNCOVERED.
Output tables only. (Coverage percentages are computed by coverage.py, not by the AI.)
```

**P4 - Code generation (stage 6)**
```
Implement the module "{module_name}" in Python.
Governing ontology slice (authoritative; do not deviate):
{ontology_slice}
Design for this module: {module_design}
Interfaces of modules it depends on: {interfaces}
Constraints: use exactly the class and attribute names from the ontology (snake_case);
read numeric parameters from the values given above, never invent constants;
add no attributes that are not in the slice; put a comment "# zs: <RuleName>" on each
piece of code that implements a rule. Output only the code file.
```

**P5 - Test derivation (stage 8)**
```
From these ontology rules and parameters, write pytest tests. One test per rule, using
the ontology's numbers as expected values, including boundary cases and a fixed random seed.
Put "# zs: <RuleName>" on each test. Rules: {rules_with_parameters}
Module under test: {interfaces}
```

**P6 - Repair (stage 9)**
```
The code below failed verification.
Violation report (each line names the ontology rule broken):
{checker_output}
Code: {code}
Governing ontology slice: {ontology_slice}
Fix ONLY what the violations describe. Do not change the ontology. Do not alter
behavior that is not mentioned. Output the corrected file and one line per violation
saying how it was fixed.
```

---

## 8. Demo Plan and Results

**Task:** add the zombie mutation feature (requirements R10-R13) to a simplified version of the simulation.

**Procedure:** run the same task four times: a naive informal request, a naive detailed request (the same facts, stated precisely), a blind naive informal request given by the author to a different AI (Copilot, in a fresh chat), and the full pipeline (stages 1 to 9 with the prompts in Section 7). The detailed naive run is included so the pipeline is compared with a strong baseline and not only a careless one, and the Copilot run is included because the assistant that wrote the other two naive runs had already seen the ontology. Five repeat informal runs and one repair-loop run were added afterwards (see the supplementary results below).

**Measurements for each run:** the `ontology_check.py` result (checks passed and violations); tests passed against the baseline; how many of the four new requirements (R10-R13) have a test (`coverage.py`); trace failures (`trace_check.py`); and repair rounds.

**Four main runs on the same base code** (the project's 14 Nov 2026 snapshot, not duplicated in this submission):

| Run | Prompt | Checker result | Tests | New requirements (R10-R13) with a test | Trace failures | Repair rounds |
|---|---|---|---|---|---|---|
| Naive, informal | one sentence, no numbers (`demo/naive/PROMPT.txt`) | 13 passed, **3 violations** | 157 passed (= baseline) | 0 / 4 | 4 | not run |
| Naive, informal, blind (Copilot) | the informal prompt in a fresh web Copilot chat, with `zombie.py` and `agent.py` as context; response applied unchanged (`demo/naive_copilot/`) | 12 passed, **5 violations** | 157 passed (= baseline) | 0 / 4 | 4 | not run |
| Naive, detailed | the same task with the approved numbers (`demo/naive_detailed/PROMPT.txt`) | 15 passed, **0 violations** | 157 passed (= baseline) | 0 / 4 | 4 | not run |
| Pipeline | stages 1-9, prompts in `demo/pipeline/prompts/` | 15 passed, **0 violations** | 166 passed (baseline 157 + 9 new) | 4 / 4 | 0 (after 1 failure fixed, see below) | 0 |

The naive runs have no trace record of their own. `trace_check.py` and `coverage.py` hold them to the same `trace.csv` the pipeline produced, which is the standard the pipeline sets for a finished change. Their four trace failures are the missing test file `tests/test_mutation.py`.

Baseline before any change: 157 passed, 13 skipped, 1 failed. The one failure is a test that needs the tkinter library, which the test environment lacks. It is the same in every run, and `tests/test_gui.py` was excluded for the same reason.

**What the runs show**
1. **Informal naive request drifted from the intent.** The three violations were Runner health (-30 instead of -20), Tank health (+60 instead of +50) and the mutation rate (0.2 instead of 0.25). Each is a number the prompt never stated, so the AI chose its own. The checker named the rule and the expected value for each.
2. **The blind Copilot run drifted from the ontology too.** Five violations, in two kinds. Behavior: it used multipliers for health (Brute x1.5, Runner x0.75, Tank x3) and its own deltas (Runner strength -1, Tank speed -2, Tank strength +1), so Brute health is 150 against 100, Runner is (75, 5, 2) against (80, 5, 3) and Tank is (300, 1, 4) against (150, 2, 3). Representation: it stores "no mutation" as the string `"Normal"`, where the ontology contract is `None`, so two violations (the default value and the turned-zombie rule) concern representation. The informal prompt did not specify any of these, which is the point: the choices were made by the AI and nothing stopped the drift. Its mutation rate (0.10 + 0.10 + 0.05 = 0.25), clamping and seeded-generator use passed. It wrote no tests and did not wire the code into spawning.
3. **The detailed naive request did not fail.** Once the intent is written precisely, a capable model implemented this small feature correctly in one shot. So on this task the pipeline's advantage is **not** that its code is more correct. The detailed prompt is, in effect, the output of pipeline stages 1 and 2 (requirements and ontology), so the pipeline is what produces that prompt.
4. **The pipeline added things the naive runs did not have, and it caught defects in its own work.**
   - The stage 2 reasoning pass found three gaps in the ontology itself: mutation not declared as at-most-one, no clamp minimum parameter, and the turned-zombie exception unstated.
   - The stage 5 trace check found that the ontology rule `R_PopulationFlow` was referenced by no requirement (`stages/05_trace_check_round1.txt`). Requirement R14 was added and the second check passed.
   - Both naive runs wrote no tests. The pipeline run added nine tests tagged with the rule they check.
   - The coverage report also shows existing debt that no run created: requirements R2 and R3 (human range and damage, zombie range and damage) have no direct unit tests in the project and are covered only by `ontology_check.py`.
5. **No regressions in any run**, as measured by the existing suite and the checker's rules for existing behavior.

**Supplementary runs: repetition and the repair loop** (details in `demo/repeat_runs_summary.md`)
- **Five more informal naive runs** from fresh AI sessions that saw only the project and the informal prompt. Violations: 6, 5, 5, 5, 4. Counting the first informal run (3) and the Copilot run (5), all 7 informal runs violated the ontology (range 3 to 6) and none of the 7 wrote a test for R10-R13. The drift is therefore not a one-off: the numbers the prompt never gave are chosen differently each time. All five used lowercase mutation names. That counts as a violation only because the ontology and the prompt use "Brute", "Runner" and "Tank"; the stat and rate violations stand without it.
- **An independent pipeline run (stages 6 and 8) was done by the author with Copilot** (`demo/pipeline_copilot/`). The author uploaded the saved P4 and P5 prompt files, with the approved ontology, to web Copilot Chat (Basic) and applied the replies. Result: 15 passed, 0 violations from the checker; 165 tests passed (baseline 157 plus 8 new); 0 trace failures; 4 / 4 new requirements with a test; 0 repair rounds. The same Copilot with the informal prompt had 5 violations and no tests. Two findings count against the pipeline and are reported in `demo/pipeline_copilot/RUN_NOTE.md`: Copilot's tests are shallow (they do not check the rate, at-most-one, or determinism, which the checker covers), so the coverage figure shows that tests exist and not that they are thorough; and one test carries a tag for an ontology term that no longer exists, which `trace_check.py` does not catch because it validates only rule tags.
- **The repair loop (P6) was exercised once.** The Copilot output (12 passed, 5 violations) was repaired by a fresh AI session given only the filled P6 prompt: the violation lines, the code, the governing ontology slice and the turned-zombie rule. The re-check shows 15 passed, 0 violations, with the existing suite unchanged. One round. The repair did not add the missing tests (still 0 / 4), because no violation named them, which shows why coverage is a separate control from the checker.

**Limits of this demo**
- One model family, one small task. The informal prompt was run seven times and the other conditions once each. This shows the process working and the naive drift recurring, not how often the pipeline improves results.
- The informal and detailed naive runs were produced by the same assistant that built the ontology, so they are not blind. The Copilot run is blind: web Copilot, a fresh chat, the informal prompt, with `src/zombie.py` and `src/agent.py` pasted as context (Copilot Chat Basic; see `demo/naive_copilot/PROMPT_NOTE.txt`). The detailed prompt has not been run blind.
- The checker was changed once during the blind run: a failed default-value check no longer stops the other mutation checks. The earlier runs were rerun and their results are unchanged.
- The pipeline's prompts are saved word for word in `demo/pipeline/prompts/` with their outputs, but they were executed in one working session by the same assistant acting for the author, not as separate model calls.
- Scope was limited to the mutation module and the `Zombie.mutation` attribute. Wiring into spawning and storing the mutation name in the database were declared out of scope.
- Approvals for stages 1, 2, 3, 4, 5 and 9 are recorded in `approvals.json` with `gate.py`, at the author's statement that the artifacts were read and approved (`demo/pipeline/stages/00_approval_record.md`). A later change to any approved artifact voids its approval.

---

## 9. Artifacts in the Repository

| File | Purpose |
|---|---|
| `README.md` | index of the package and how to run it |
| `requirements.md` | stage 1 requirements R1-R14 and approval row |
| `zombie_ontology.ttl` | the ontology (entities, relations, rules, parameters) |
| `trace.csv` | requirement -> ontology terms -> code files -> test files |
| `validate_ontology.py` | stage 3 validation |
| `trace_check.py` | trace enforcement (stages 5-8) |
| `coverage.py` | coverage metrics (stages 5, 6, 8) |
| `ontology_check.py` | stage 7 checker |
| `gate.py` | approval gates (hash-based) |
| `approvals.json` | the recorded approvals (stages 1, 2, 3, 4, 5 and 9) with the hash of each approved file |
| `PIPELINE.md` | this document |
| `demo/README.md` | how the demo is organized and how to reproduce it |
| `demo/gate_demo.txt` | `gate.py` blocked, allowed and voided on a throwaway file |
| `demo/pipeline_copilot/` | independent run of stages 6 and 8 by the author with Copilot: raw replies, applied code and tests, reports, `RUN_NOTE.md` |
| `demo/naive_rep1/` to `demo/naive_rep5/`, `demo/naive_copilot_repair/`, `demo/repeat_runs_summary.md` | five repeat informal runs and the P6 repair exercise (code, reports, repair prompt and output) |
| `demo/naive/`, `demo/naive_detailed/`, `demo/naive_copilot/` | prompt, generated code, checker, trace and coverage reports for each naive run (the Copilot run also holds its full response) |
| `demo/pipeline/` | stage artifacts (`stages/`), every stage prompt and output (`prompts/`), earlier ontology versions (`ontology_versions/`), generated code, tests, approval record |

## 10. Limitations
- The ontology is only as correct as its review. The checker proves code matches the ontology, not that the ontology matches what the designer wants.
- The scripts check what they are told to check. `trace.csv` is written by the author and the AI, so a wrong or padded trace file still passes. A rule that `ontology_check.py` has no check for is not tested by it. At present it executes checks for R_RangeHuman, R_RangeZombie, R_DeadInert, R_TurnKeepsIdentity and R_Mutation, and R_Determinism only for the mutation roll. R_SectorMixed and R_PopulationFlow depend on the project's existing tests.
- Approval gates in a single-author project prove that review happened, by whom, and that nothing changed afterwards. They do not prove the review was wise.
- The gates block only when `gate.py require` is run. They are a process control and not a technical lock: nothing stops someone from skipping the command.
- The behavioral checks sample inputs and do not prove correctness for every input.
- The existing project has no direct unit tests for the human and zombie range, hit chance and damage rules (R2, R3). The coverage report lists this as known debt.
- The repair prompt (P6) was exercised once, on the Copilot output, not on the pipeline's own run (which needed 0 repair rounds). One successful round does not test the 3-round limit or a failure that resists repair.
- Results from one model family and one task do not establish how the pipeline performs in general. The repeat runs and the repair run were made by fresh sessions of the same model family as the assistant that built the ontology and the checker, so they are blind to the ontology but not independent of its author. Only stages 6 and 8 were run independently (by the author, with Copilot); stages 1 to 5 and 9 were not, and the ontology and checker are the assistant's work.
