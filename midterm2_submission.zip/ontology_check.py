"""Ontology conformance checker for the zombie simulation.
Author: Mack Miracle (CPS 310 Fall 2026, Midterm #2)

Usage:  python ontology_check.py <path-to-project-root> [ontology.ttl]

Layer A (structural, AST):   classes and attributes in the code must exist in the ontology.
Layer B (behavioural):       the code is imported and each ontology rule is executed.
Exit code 0 = conforms, 1 = violations found.  Every violation names the ontology rule.
"""
from __future__ import annotations
import ast, importlib, random, sys, types
from pathlib import Path
import rdflib
from rdflib import RDF

ZS = rdflib.Namespace("http://example.org/zombie-sim#")
violations: list[str] = []
passed: list[str] = []


def bad(rule: str, msg: str): violations.append(f"[{rule}] {msg}")
def ok(rule: str, msg: str): passed.append(f"[{rule}] {msg}")


def load_ontology(path: Path):
    g = rdflib.Graph(); g.parse(path, format="turtle")
    def p(rule, prop):
        v = g.value(ZS[rule], ZS[prop]); return float(v) if v is not None else None
    props = {"Agent": set(), "Human": set(), "Zombie": set()}
    for prop in g.subjects(rdflib.RDF.type, rdflib.OWL.DatatypeProperty):
        dom = g.value(prop, rdflib.RDFS.domain)
        if dom is not None:
            props.setdefault(str(dom).split("#")[1], set()).add(str(prop).split("#")[1])
    for prop in g.subjects(RDF.type, rdflib.OWL.ObjectProperty):
        dom, rng = g.value(prop, rdflib.RDFS.domain), g.value(prop, rdflib.RDFS.range)
        if dom is not None and rng == ZS.Mutation:
            props.setdefault(str(dom).split("#")[1], set()).add(str(prop).split("#")[1])
    return g, p, props


def snake(name: str) -> str:
    return "".join("_" + c.lower() if c.isupper() else c for c in name)


# ---------------- Layer A: structure ----------------
def check_structure(root: Path, props):
    allowed = {
        "Agent": {snake(n) for n in props["Agent"]} | {"agent_type"},
        "Human": {snake(n) for n in props["Human"]},
        "Zombie": {snake(n) for n in props["Zombie"]},
    }
    found = set()
    for f in (root / "src").glob("*.py"):
        tree = ast.parse(f.read_text())
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef) and node.name in allowed:
                found.add(node.name)
                fields = {n.target.id for n in node.body
                          if isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name)}
                extra = fields - allowed[node.name]
                if extra:
                    bad("Ontology:properties", f"{node.name} declares attributes not in the ontology: {sorted(extra)}")
                else:
                    ok("Ontology:properties", f"{node.name} attributes all declared in ontology")
    for cls in ("Agent", "Human", "Zombie"):
        if cls not in found:
            bad("Ontology:classes", f"class {cls} missing from code")


# ---------------- Layer B: behaviour ----------------
def check_behaviour(root: Path, p):
    sys.path.insert(0, str(root))
    for m in [m for m in sys.modules if m.split(".")[0] in ("src", "utils", "config", "runtime")]:
        del sys.modules[m]
    try:
        Human = importlib.import_module("src.human").Human
        Zombie = importlib.import_module("src.zombie").Zombie
        cfg = importlib.import_module("config.simulation_config")
    except Exception as e:
        bad("Import", f"cannot import project modules: {e!r}"); return

    def mk_h(tier, **kw):
        return Human(agent_id=1, agent_type="human", is_alive=True, x_pos=0.0, y_pos=0.0,
                     health=kw.get("health", 100), speed=kw.get("speed", 3), weapon_tier=tier,
                     is_super=kw.get("is_super", False), is_champion=kw.get("is_champion", False))
    def mk_z(strength):
        return Zombie(agent_id=2, agent_type="zombie", is_alive=True, x_pos=0.0, y_pos=0.0,
                      health=100, speed=3, strength=strength)

    # R_RangeHuman
    rpt, base, fall, floor = (p("R_RangeHuman", k) for k in ("rangePerTier", "hitBase", "hitFalloff", "hitFloor"))
    lo, hi = (p("R_RangeHuman", k) for k in ("dmgLowMult", "dmgHighMult"))
    good = True
    for tier in range(1, 7):
        h = mk_h(tier)
        if abs(h.max_range - tier * rpt) > 1e-9:
            bad("R_RangeHuman", f"tier {tier}: range {h.max_range}, ontology says {tier*rpt}"); good = False
        if h.hit_chance(tier * rpt + 0.01) != 0.0:
            bad("R_RangeHuman", f"tier {tier}: hit chance beyond range must be 0"); good = False
        for d in (0.0, 1.0, tier * rpt / 2, tier * rpt):
            want = max(floor, min(base, base - fall * d / tier))
            if abs(h.hit_chance(d) - want) > 1e-9:
                bad("R_RangeHuman", f"tier {tier} d={d}: hit chance {h.hit_chance(d):.4f}, expected {want:.4f}"); good = False
        rng = random.Random(1)
        dmg = [h.roll_damage(rng) for _ in range(400)]
        if min(dmg) < tier * lo or max(dmg) > tier * hi:
            bad("R_RangeHuman", f"tier {tier}: damage {min(dmg)}..{max(dmg)} outside {tier*lo}..{tier*hi}"); good = False
    if good: ok("R_RangeHuman", "range, hit chance and damage match the ontology for tiers 1-6")

    # R_RangeZombie
    ar, zlo, zhi = (p("R_RangeZombie", k) for k in ("attackRange", "dmgLowMult", "dmgHighMult"))
    z = mk_z(3); good = True
    if abs(z.attack_range - ar) > 1e-9:
        bad("R_RangeZombie", f"attack range {z.attack_range}, ontology says {ar}"); good = False
    if not (z.can_reach(ar) and not z.can_reach(ar + 0.01)):
        bad("R_RangeZombie", "can_reach does not cut off at the ontology range"); good = False
    for s in range(1, 6):
        rng = random.Random(2); dmg = [mk_z(s).roll_damage(rng) for _ in range(400)]
        if min(dmg) < s * zlo or max(dmg) > s * zhi:
            bad("R_RangeZombie", f"strength {s}: damage {min(dmg)}..{max(dmg)} outside {s*zlo}..{s*zhi}"); good = False
    if good: ok("R_RangeZombie", "range and damage match the ontology")

    # R_DeadInert
    h = mk_h(2); h.is_alive = False
    moved = h.planned_move(10.0, 10.0)
    if moved[2] != 0.0: bad("R_DeadInert", "a dead agent moved")
    else: ok("R_DeadInert", "dead agents do not move")

    # R_TurnKeepsIdentity
    tc, th = p("R_TurnKeepsIdentity", "turnChance"), p("R_TurnKeepsIdentity", "turnHealth")
    if abs(getattr(cfg, "HUMAN_TURN_CHANCE", -1) - tc) > 1e-9:
        bad("R_TurnKeepsIdentity", f"HUMAN_TURN_CHANCE={getattr(cfg,'HUMAN_TURN_CHANCE',None)}, ontology says {tc}")
    else: ok("R_TurnKeepsIdentity", f"turn chance is {tc}")
    if not hasattr(Zombie, "from_human"):
        bad("R_TurnKeepsIdentity", "Zombie.from_human is missing: a turned human has no defined result")
    else:
        h = mk_h(4, speed=5, is_super=True, is_champion=True); h.x_pos, h.y_pos = 7.0, 9.0
        z = Zombie.from_human(h); good = True
        for what, got, want in (("agent_id", z.agent_id, h.agent_id), ("x_pos", z.x_pos, 7.0), ("y_pos", z.y_pos, 9.0),
                                ("speed", z.speed, 5), ("strength", z.strength, 4), ("health", z.health, th),
                                ("is_super", z.is_super, True), ("is_champion", z.is_champion, True)):
            if got != want: bad("R_TurnKeepsIdentity", f"turned zombie {what}={got}, expected {want}"); good = False
        if not z.is_alive: bad("R_TurnKeepsIdentity", "turned zombie is not alive"); good = False
        if good: ok("R_TurnKeepsIdentity", "turned zombie keeps id, position, speed, flags; strength = tier; health = floor")


def check_mutation(root: Path, g):
    mods = {}
    for name in ("Brute", "Runner", "Tank"):
        mods[name] = tuple(int(g.value(ZS[name], ZS[k]) or 0) for k in ("deltaHealth", "deltaSpeed", "deltaStrength"))
    chance = float(g.value(ZS.R_Mutation, ZS.mutationChance)); minstat = int(g.value(ZS.R_Mutation, ZS.minStat))
    try:
        Zombie = importlib.import_module("src.zombie").Zombie
        mut = importlib.import_module("src.mutation")
    except Exception as e:
        bad("R_Mutation", f"cannot import src.mutation or Zombie: {e!r}"); return
    def mk(h=100, sp=3, st=3):
        return Zombie(agent_id=2, agent_type="zombie", is_alive=True, x_pos=0.0, y_pos=0.0, health=h, speed=sp, strength=st)
    z = mk()
    if not hasattr(z, "mutation"):
        bad("R_Mutation", "Zombie.mutation attribute is missing"); return
    if z.mutation is not None:
        bad("R_Mutation", f"Zombie.mutation defaults to {z.mutation!r}; the ontology contract is None (no mutation)")
    else:
        ok("R_Mutation", "Zombie.mutation exists and defaults to None")
    good = True
    for name, (dh, ds, dst) in mods.items():
        z = mk()
        try: mut.apply_mutation(z, name)
        except Exception as e: bad("R_Mutation", f"apply_mutation(z, '{name}') raised {e!r}"); good = False; continue
        want = (max(minstat, 100 + dh), max(minstat, 3 + ds), max(minstat, 3 + dst))
        got = (z.health, z.speed, z.strength)
        if got != want or z.mutation != name:
            bad("R_Mutation", f"{name}: (health,speed,strength)={got} mutation={z.mutation!r}, ontology says {want} / '{name}'"); good = False
    if good: ok("R_Mutation", "Brute, Runner and Tank apply the ontology's stat deltas")
    z = mk(h=10, sp=1, st=1)
    try:
        mut.apply_mutation(z, "Runner"); mut.apply_mutation(mk(sp=1), "Brute")
        zz = mk(h=10, sp=1, st=1); mut.apply_mutation(zz, "Runner")
        zb = mk(sp=1); mut.apply_mutation(zb, "Brute")
        if zz.health < minstat or zb.speed < minstat: bad("R_Mutation", f"clamp to 1 violated: Runner on health 10 -> {zz.health}, Brute on speed 1 -> {zb.speed}")
        else: ok("R_Mutation", "stats clamp to a minimum of 1")
    except Exception as e:
        bad("R_Mutation", f"clamp check raised {e!r}")
    try:
        rng = random.Random(7); draws = [mut.roll_mutation(rng) for _ in range(6000)]
        frac = sum(d is not None for d in draws) / len(draws)
        names = {d for d in draws if d is not None}
        if abs(frac - chance) > 0.03: bad("R_Mutation", f"mutation rate {frac:.3f}, ontology says {chance}")
        else: ok("R_Mutation", f"mutation rate {frac:.3f} matches {chance}")
        if not names <= set(mods) or len(names) != 3: bad("R_Mutation", f"roll_mutation names {sorted(map(str,names))}, expected exactly {sorted(mods)}")
        else: ok("R_Mutation", "roll_mutation returns only Brute, Runner, Tank (all three occur)")
        random.seed(1); a = [mut.roll_mutation(random.Random(5)) for _ in range(50)]
        random.seed(999); b = [mut.roll_mutation(random.Random(5)) for _ in range(50)]
        if a != b: bad("R_Determinism", "roll_mutation depends on the global random state, not only the generator passed in")
        else: ok("R_Determinism", "roll_mutation uses only the generator it is given")
    except Exception as e:
        bad("R_Mutation", f"roll_mutation check raised {e!r}")
    try:
        Human = importlib.import_module("src.human").Human
        h = Human(agent_id=1, agent_type="human", is_alive=True, x_pos=0.0, y_pos=0.0, health=10, speed=3, weapon_tier=2)
        tm = Zombie.from_human(h).mutation
        if tm is not None: bad("R_Mutation", f"a turned zombie must have no mutation (None), found {tm!r}")
        else: ok("R_Mutation", "a turned zombie has no mutation")
    except Exception as e:
        bad("R_Mutation", f"turned-zombie check raised {e!r}")


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    root = Path(args[0]).resolve()
    onto = Path(args[1]) if len(args) > 1 else Path(__file__).with_name("zombie_ontology.ttl")
    g, p, props = load_ontology(onto)
    check_structure(root, props)
    check_behaviour(root, p)
    if "--mutation" in sys.argv: check_mutation(root, g)
    for line in passed: print("PASS", line)
    for line in violations: print("FAIL", line)
    print(f"\n{len(passed)} passed, {len(violations)} violations")
    sys.exit(1 if violations else 0)

if __name__ == "__main__":
    main()
