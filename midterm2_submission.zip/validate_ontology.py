"""Stage 3: ontology validation. Usage: python validate_ontology.py [ontology.ttl]
Author: Mack Miracle (CPS 310 Fall 2026, Midterm #2)
Checks: parses, Human/Zombie subclass Agent and are disjoint, required rules carry their
parameters, and competency questions are answerable by querying the graph."""
import sys
from pathlib import Path
import rdflib
from rdflib import RDF, RDFS, OWL

ZS = rdflib.Namespace("http://example.org/zombie-sim#")
path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).with_name("zombie_ontology.ttl")
fails = []
def check(cond, msg):
    print(("PASS " if cond else "FAIL ") + msg)
    if not cond: fails.append(msg)

g = rdflib.Graph()
try:
    g.parse(path, format="turtle"); check(True, f"parses ({len(g)} triples)")
except Exception as e:
    check(False, f"parses: {e}"); sys.exit(1)

for c in ("Human", "Zombie"):
    check((ZS[c], RDFS.subClassOf, ZS.Agent) in g, f"{c} is a subclass of Agent")
check((ZS.Human, OWL.disjointWith, ZS.Zombie) in g, "Human and Zombie are disjoint")

required = {
    "R_RangeHuman": ["rangePerTier", "hitBase", "hitFalloff", "hitFloor", "dmgLowMult", "dmgHighMult"],
    "R_RangeZombie": ["attackRange", "dmgLowMult", "dmgHighMult"],
    "R_TurnKeepsIdentity": ["turnChance", "turnHealth"],
    "R_Mutation": ["mutationChance", "minStat"],
}
for rule, params in required.items():
    for p in params:
        check(g.value(ZS[rule], ZS[p]) is not None, f"{rule} has parameter {p}")
check((ZS.mutation, RDF.type, OWL.FunctionalProperty) in g, "mutation is functional (at most one per zombie, R10)")
for rule in ("R_DeadInert", "R_Determinism", "R_SectorMixed", "R_PopulationFlow", "R_Mutation"):
    check((ZS[rule], RDF.type, ZS.Rule) in g, f"rule {rule} is declared")

# Competency questions answered by querying the ontology
q1 = list(g.query("SELECT ?r WHERE { ?r a zs:Rule . ?r rdfs:comment ?c . FILTER(CONTAINS(?c,'turn')) }",
                  initNs={"zs": ZS, "rdfs": RDFS}))
check(len(q1) > 0, "CQ1 'what happens when a human takes lethal zombie damage?' is answered (turning rule found)")
q2 = {str(s).split('#')[1] for s in g.subjects(RDFS.domain, ZS.Zombie)}
check("strength" in q2, "CQ2 'which attributes belong only to a zombie?' -> " + ", ".join(sorted(q2)))
q3 = {str(s).split('#')[1] for s in g.subjects(RDFS.domain, ZS.Human)}
check("weaponTier" in q3, "CQ3 'which attributes belong only to a human?' -> " + ", ".join(sorted(q3)))

print(f"\n{len(fails)} failure(s)")
sys.exit(1 if fails else 0)
