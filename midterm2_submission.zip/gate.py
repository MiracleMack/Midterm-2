"""Formal approval gates (pipeline stage gates).
Author: Mack Miracle (CPS 310 Fall 2026, Midterm #2)

  python gate.py approve <stage> --by "Name" <artifact> [<artifact> ...]   record approval + file hashes
  python gate.py verify                                                     fail if an approved artifact changed
  python gate.py require <stage>                                            fail unless <stage> is approved and unchanged

Approvals are stored in approvals.json. An approval is VOID if any of its artifacts no longer
matches the recorded SHA-256 hash, so changing an approved file forces a new approval.
"""
import hashlib, json, sys, datetime
from pathlib import Path

STORE = Path("approvals.json")


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def load():
    return json.loads(STORE.read_text()) if STORE.exists() else {}


def status(rec):
    bad = [f for f, h in rec["artifacts"].items() if not Path(f).exists() or sha(f) != h]
    return bad


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    data = load()
    if cmd == "approve":
        stage, args = sys.argv[2], sys.argv[3:]
        if "--by" not in args:
            sys.exit("approve needs --by \"Name\"")
        i = args.index("--by"); by = args[i + 1]; files = args[:i] + args[i + 2:]
        data[stage] = {"approved_by": by, "date": datetime.date.today().isoformat(),
                       "artifacts": {f: sha(f) for f in files}}
        STORE.write_text(json.dumps(data, indent=2))
        print(f"stage {stage} approved by {by}: {len(files)} artifact(s) hashed")
    elif cmd == "verify":
        void = 0
        for stage, rec in sorted(data.items()):
            bad = status(rec)
            print(("VOID  " if bad else "VALID ") + f"stage {stage} (approved by {rec['approved_by']}, {rec['date']})" + (f" changed: {bad}" if bad else ""))
            void += bool(bad)
        sys.exit(1 if void else 0)
    elif cmd == "require":
        stage = sys.argv[2]
        if stage not in data:
            print(f"BLOCKED: stage {stage} has no approval"); sys.exit(1)
        bad = status(data[stage])
        if bad:
            print(f"BLOCKED: stage {stage} approval is void, changed: {bad}"); sys.exit(1)
        print(f"OK: stage {stage} approved and unchanged")
    else:
        sys.exit(__doc__)


if __name__ == "__main__":
    main()
