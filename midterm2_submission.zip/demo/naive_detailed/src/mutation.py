"""Zombie mutations."""

import random

MUTATION_CHANCE = 0.25
MUTATIONS = {
    "Brute": {"strength": 2, "speed": -1},
    "Runner": {"speed": 2, "health": -20},
    "Tank": {"health": 50, "speed": -1},
}


def roll_mutation(rng: random.Random):
    if rng.random() < MUTATION_CHANCE:
        return rng.choice(list(MUTATIONS))
    return None


def apply_mutation(zombie, name):
    for stat, delta in MUTATIONS[name].items():
        setattr(zombie, stat, max(1, getattr(zombie, stat) + delta))
    zombie.mutation = name
