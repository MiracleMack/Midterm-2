"""Zombie mutations: Brute, Runner and Tank."""

from __future__ import annotations

import random

# Probability that a zombie is mutated at all.
MUTATION_CHANCE = 0.2

# name -> (weight, strength multiplier, speed multiplier, health multiplier)
MUTATIONS: dict[str, tuple[float, float, float, float]] = {
    "brute": (1.0, 1.5, 0.7, 1.0),
    "runner": (1.0, 0.7, 1.5, 1.0),
    "tank": (1.0, 1.0, 0.7, 2.0),
}


def roll_mutation(rng: random.Random) -> str | None:
    """Return a mutation name, or None if this zombie stays normal."""
    if rng.random() >= MUTATION_CHANCE:
        return None
    names = list(MUTATIONS)
    weights = [MUTATIONS[n][0] for n in names]
    return rng.choices(names, weights=weights, k=1)[0]


def apply_mutation(zombie, name: str | None):
    """Apply the named mutation's stat changes to ``zombie`` in place."""
    if name is None:
        return zombie
    key = name.lower()
    if key not in MUTATIONS:
        raise ValueError(f"unknown mutation: {name!r}")
    if getattr(zombie, "mutation", None) is not None:
        return zombie  # never stack mutations
    _, s_mult, v_mult, h_mult = MUTATIONS[key]
    zombie.strength = max(1, round(zombie.strength * s_mult))
    zombie.speed = max(1, round(zombie.speed * v_mult))
    zombie.health = max(1, round(zombie.health * h_mult))
    zombie.mutation = key
    return zombie
