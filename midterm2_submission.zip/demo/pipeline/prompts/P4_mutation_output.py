"""Zombie mutations (requirements R10-R13).

All numbers below come from the ontology (zombie_ontology.ttl, rule R_Mutation).
"""

from __future__ import annotations

import random

# zs: R_Mutation - probability that a spawned zombie receives a mutation
MUTATION_CHANCE = 0.25

# zs: R_Mutation - minimum value of health, speed and strength after a mutation
MIN_STAT = 1

# zs: R_Mutation - (deltaHealth, deltaSpeed, deltaStrength) per mutation
MUTATIONS = {
    "Brute": (0, -1, 2),
    "Runner": (-20, 2, 0),
    "Tank": (50, -1, 0),
}


def roll_mutation(rng: random.Random) -> str | None:
    """Return a mutation name, or None. Uses only the generator passed in."""
    # zs: R_Determinism - no global random state
    if rng.random() < MUTATION_CHANCE:
        return rng.choice(sorted(MUTATIONS))
    return None


def apply_mutation(zombie, name: str) -> None:
    """Apply a mutation's deltas, clamp to MIN_STAT, and record the name."""
    # zs: R_Mutation
    d_health, d_speed, d_strength = MUTATIONS[name]
    zombie.health = max(MIN_STAT, zombie.health + d_health)
    zombie.speed = max(MIN_STAT, zombie.speed + d_speed)
    zombie.strength = max(MIN_STAT, zombie.strength + d_strength)
    zombie.mutation = name
