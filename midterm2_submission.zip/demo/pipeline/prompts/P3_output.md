# Stage 5 - Design compliance (prompt P3) and trace check (script)

**A. Design element -> ontology term**
| Design element | Term | Status |
|---|---|---|
| `MUTATIONS` table | Mutation, Brute, Runner, Tank, delta properties | ok |
| `MUTATION_CHANCE` | R_Mutation.mutationChance | ok |
| `MIN_STAT` | R_Mutation.minStat | ok |
| `roll_mutation` | R_Mutation, mutation (functional), R_Determinism | ok |
| `apply_mutation` | R_Mutation, deltas, minStat | ok |
| `Zombie.mutation` | mutation | ok |
| `Zombie.from_human` unchanged | R_Mutation (turned-zombie exception) | ok |
Orphans: **0**.

**B. Rule -> design element**
R_Mutation: covered. R_Determinism: covered for the mutation roll. Other rules (R_RangeHuman, R_RangeZombie, R_DeadInert, R_TurnKeepsIdentity, R_SectorMixed, R_PopulationFlow) are not touched by this change and stay with the existing code. Uncovered rules for this task: **0**.

**Computed by script (not by the AI):** see `05_trace_check_round1.txt`, `05_trace_check_round2.txt` and `06_coverage.txt`.
- Round 1 of `trace_check.py` failed: the ontology rule `R_PopulationFlow` was referenced by no requirement. Fix: requirement **R14** was added (existing behavior, marked E) and needs the author's approval.
- Round 2 passed with 0 failures.
- Declared out of scope: spawner wiring and database persistence of the mutation name.
