"""Tests derived from the ontology rule R_Mutation (pipeline stage 8, prompt P5)."""

import random
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.human import Human  # noqa: E402
from src.mutation import MUTATIONS, apply_mutation, roll_mutation  # noqa: E402
from src.zombie import Zombie  # noqa: E402


def zombie(health=100, speed=3, strength=3):
    return Zombie(agent_id=1, agent_type="zombie", is_alive=True, x_pos=0.0, y_pos=0.0,
                  health=health, speed=speed, strength=strength)


class MutationTests(unittest.TestCase):
    def test_default_none(self):  # zs: R_Mutation
        self.assertIsNone(zombie().mutation)

    def test_brute_deltas(self):  # zs: R_Mutation
        z = zombie(); apply_mutation(z, "Brute")
        self.assertEqual((z.health, z.speed, z.strength, z.mutation), (100, 2, 5, "Brute"))

    def test_runner_deltas(self):  # zs: R_Mutation
        z = zombie(); apply_mutation(z, "Runner")
        self.assertEqual((z.health, z.speed, z.strength, z.mutation), (80, 5, 3, "Runner"))

    def test_tank_deltas(self):  # zs: R_Mutation
        z = zombie(); apply_mutation(z, "Tank")
        self.assertEqual((z.health, z.speed, z.strength, z.mutation), (150, 2, 3, "Tank"))

    def test_clamp_minimum_one(self):  # zs: R_Mutation (R12)
        z = zombie(health=10, speed=1, strength=1); apply_mutation(z, "Runner")
        self.assertEqual(z.health, 1)
        z = zombie(speed=1); apply_mutation(z, "Brute")
        self.assertEqual(z.speed, 1)

    def test_only_three_mutations(self):  # zs: R_Mutation
        self.assertEqual(set(MUTATIONS), {"Brute", "Runner", "Tank"})

    def test_rate_close_to_quarter(self):  # zs: R_Mutation (R10)
        rng = random.Random(11)
        draws = [roll_mutation(rng) for _ in range(8000)]
        self.assertAlmostEqual(sum(d is not None for d in draws) / 8000, 0.25, delta=0.02)

    def test_same_seed_same_rolls_regardless_of_global_state(self):  # zs: R_Determinism (R13)
        random.seed(1); a = [roll_mutation(random.Random(5)) for _ in range(40)]
        random.seed(2); b = [roll_mutation(random.Random(5)) for _ in range(40)]
        self.assertEqual(a, b)

    def test_turned_zombie_has_no_mutation(self):  # zs: R_Mutation (R13)
        h = Human(agent_id=3, agent_type="human", is_alive=True, x_pos=0.0, y_pos=0.0,
                  health=5, speed=3, weapon_tier=2)
        self.assertIsNone(Zombie.from_human(h).mutation)


if __name__ == "__main__":
    unittest.main()
