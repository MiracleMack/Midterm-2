"""Zombie agent: short fixed-range melee attacker."""

from __future__ import annotations

import random
from dataclasses import dataclass

from config import simulation_config as cfg
from src.agent import Agent
from utils import combat


@dataclass
class Zombie(Agent):
    strength: int = 1
    # zs: R_Mutation - at most one mutation per zombie; None for turned zombies
    mutation: str | None = None

    def __post_init__(self) -> None:
        super().__post_init__()
        self.strength = max(1, int(self.strength))

    @property
    def attack_range(self) -> float:
        """Fixed reach - zombies cannot attack from farther away."""
        return cfg.ZOMBIE_ATTACK_RANGE

    @property
    def hold_distance(self) -> float:
        """How close a zombie closes before it stops."""
        return cfg.ZOMBIE_STOP_DISTANCE

    def can_reach(self, distance: float) -> bool:
        return distance <= self.attack_range

    def roll_damage(self, rng: random.Random) -> int:
        return combat.zombie_damage(self.strength, rng)

    @classmethod
    def from_human(cls, human) -> "Zombie":
        """The zombie a turned human becomes: stats carry, health is the floor."""
        return cls(
            agent_id=human.agent_id,
            agent_type="zombie",
            is_alive=True,
            x_pos=human.x_pos,
            y_pos=human.y_pos,
            health=cfg.ZOMBIE_HEALTH_RANGE[0],
            speed=human.speed,
            strength=human.weapon_tier,
            is_super=human.is_super,
            is_champion=human.is_champion,
        )
