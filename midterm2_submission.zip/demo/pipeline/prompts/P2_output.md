# Stage 4 - Design (prompt P2). Scope: R10-R13 at module level.

| Module | Responsibility | Ontology terms used | Depends on |
|---|---|---|---|
| `src/mutation.py` (new) | holds the three mutations and their deltas; `roll_mutation(rng)` returns a name or None; `apply_mutation(zombie, name)` applies deltas, clamps, records the name | Mutation, Brute, Runner, Tank, deltaHealth/deltaSpeed/deltaStrength, R_Mutation.mutationChance, R_Mutation.minStat, R_Determinism | `random` (generator passed in only) |
| `src/zombie.py` (changed) | gains attribute `mutation` (default None); `from_human` leaves it None | Zombie, mutation, R_Mutation (turned-zombie exception) | none |

ONTOLOGY GAPS: none.
Out of scope for the demo (declared): wiring `roll_mutation` into `generate_spawns`, and saving the mutation name in the database. Stats changed by a mutation persist like any other stats.
