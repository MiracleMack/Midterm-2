# Stage 2 - Reasoning pass (prompt R1) on ontology v0.5 with requirements R1-R13

1. **Contradictions.** None. Human and Zombie are disjoint; turning is modelled as a state change of one identity (Turning event), so no individual is in both classes.
2. **Rules missing a parameter or constraint** (three found; all fixed in v0.6):
   - R10 says a zombie has "at most one" mutation, but `zs:mutation` was not declared functional -> added `owl:FunctionalProperty`.
   - R12 requires clamping to a minimum of 1, but `R_Mutation` had no `minStat` parameter -> added `zs:minStat 1`.
   - R13 says a turned zombie has no mutation, but the ontology did not say so -> added to the R_Mutation rule text.
3. **Requirement -> ontology terms:** R1 Agent/Human/Zombie; R2 R_RangeHuman; R3 R_RangeZombie; R4 R_DeadInert; R5 turnsInto/Turning/R_TurnKeepsIdentity; R6 Tick; R7 Sector/R_SectorMixed; R8 Run/R_Determinism; R9 isChampion/promotedTo; R10 mutation (functional)/R_Mutation.mutationChance; R11 Mutation/Brute/Runner/Tank; R12 R_Mutation.minStat; R13 R_Mutation/R_Determinism. **Unmapped: none (13 of 13 = 100%).**
4. **Competency questions:** (a) A human killed by a zombie turns with probability 0.10 into a zombie with the same id. (b) Mutations a zombie can have: at most one of Brute, Runner, Tank, with probability 0.25. (c) A turned zombie has no mutation.
