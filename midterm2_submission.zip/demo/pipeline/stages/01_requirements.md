# Requirements (Pipeline Stage 1)

Each requirement is one testable statement. Status: **E** = already in the code, **N** = new feature for the demo.
R10-R13 were proposed by the assistant and approved by the author at the stage 1 gate.

| ID | Status | Requirement |
|---|---|---|
| R1 | E | Agents are Humans or Zombies. They share health, speed, position and alive state; humans have a weapon tier (>= 1) and zombies have a strength (>= 1). |
| R2 | E | A human's attack range is weapon tier x 2.5. Its hit chance is clamp(0.9 - 0.045 x distance / tier, 0.05, 0.9) and is 0 beyond range. Its damage is a random integer in [tier x 3, tier x 9]. |
| R3 | E | A zombie attacks only within range 2.5, always hits in range, and deals a random integer in [strength x 5, strength x 15]. |
| R4 | E | A dead agent never moves or attacks. |
| R5 | E | A human killed by a zombie turns into a zombie with probability 0.10. The turned zombie keeps the same id, position and speed, its strength equals the human's weapon tier, its health is 50, and super and champion flags carry over. It is never marked dead. |
| R6 | E | Each tick runs a movement phase and then a combat phase. Each phase plans from a frozen snapshot and then applies in agent_id order. |
| R7 | E | The map is divided into a fixed grid of sectors, and each sector is simulated independently. Every sector holds at least one human and one zombie after merging. |
| R8 | E | All randomness is seeded. The same seed gives the same result for any worker count. |
| R9 | E | Run survivors become champions. When carried over, health resets and speed and tier or strength each gain 1 to 3 with no cap. |
| R10 | N | Each spawned zombie receives a mutation with probability 0.25. A zombie has at most one mutation. |
| R11 | N | There are three mutations: Brute (strength +2, speed -1), Runner (speed +2, health -20) and Tank (health +50, speed -1). |
| R12 | N | After a mutation is applied, health, speed and strength are clamped to a minimum of 1. |
| R13 | N | Mutation choice and the mutation roll use the seeded generator, so R8 still holds. A zombie that was a turned human (R5) has no mutation. |
| R14 | E | Humans never increase in number during a run; zombies increase only through the turning in R5. (added by the stage 5 trace check) |

## Approval record
| Stage | Approved by | Date | Notes |
|---|---|---|---|
| 1 Requirements | Mack Miracle | 2026-11-24 | R1-R14 approved with gate.py (see approvals.json) |
