# Ontology version history for the mutation run

| Version | File | What it is |
|---|---|---|
| v0.4 | `../ontology_versions/v0.4_before_mutation.ttl` | input to prompt P1: entities, relations and rule parameters, with turning modelled as one identity changing state (Turning event). No mutation yet. |
| v0.5 | `../ontology_versions/v0.5_after_P1.ttl` | after P1: adds Mutation, Brute, Runner, Tank, the `mutation` attribute and rule `R_Mutation`. Input to the reasoning prompt R1. |
| v0.6 | `02_ontology_v0.6.ttl` (the same file as `zombie_ontology.ttl`) | after R1 found three gaps (below). This is the approved ontology. |

## Changes made by the reasoning pass (v0.5 -> v0.6)
1. `zs:mutation` declared `owl:FunctionalProperty` (R10: at most one mutation per zombie).
2. New data property `zs:minStat` with value 1 on `zs:R_Mutation` (R12: clamp to a minimum of 1).
3. `zs:R_Mutation` text extended: draws use only the generator passed in, and a zombie created by turning has no mutation (R13).
