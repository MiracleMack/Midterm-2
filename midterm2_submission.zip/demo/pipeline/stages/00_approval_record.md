# Approval record - pipeline run on the mutation task (2026-11-24)

| Stage | Artifact | Checks passed | Coverage | Approved by | Date | Notes |
|---|---|---|---|---|---|---|
| 1 Requirements | `requirements.md` (R1-R14) | all items testable, IDs unique | 14 requirements | Mack Miracle | 2026-11-24 | recorded with `gate.py approve 1` (see `approvals.json`), at the author's instruction. R14 was added by the trace check. |
| 2 Ontology | `02_ontology_v0.6.ttl` | reasoning pass: 0 contradictions, 3 gaps fixed | 14/14 requirements mapped (R14 added at stage 5) | Mack Miracle | 2026-11-24 | v0.6 changes: functional `mutation`, `minStat`, turned-zombie exception |
| 3 Validation | `03_validation_report.txt` | 0 failures | all rules parameterised | Mack Miracle | 2026-11-24 | |
| 4 Design | `04_design.md` | 0 ontology gaps | | Mack Miracle | 2026-11-24 | |
| 5 Compliance | `05_compliance_tables.md` | 0 orphans, 0 uncovered | 4/4 R10-R13 at module level | Mack Miracle | 2026-11-24 | spawner wiring and DB persistence declared out of scope |
| 6 Code | `src/mutation.py`, `src/zombie.py` | imports | | (no gate) | | |
| 7 Verification | `07_checker_report.txt` | 15 passed, 0 violations | | (script gate) | | |
| 8 Testing | `08_test_report.txt` | 166 passed, 13 skipped, 1 failed (needs tkinter, which the test environment lacks; same as baseline) | | (script gate) | | |
| 9 Loop | no failures, 0 repair rounds | | | Mack Miracle | 2026-11-24 | |

All gated stages (1, 2, 3, 4, 5, 9) are recorded in `approvals.json` with `gate.py`, at the author's statement that the artifacts were read and approved. `python gate.py verify` shows each as VALID while its files are unchanged.
