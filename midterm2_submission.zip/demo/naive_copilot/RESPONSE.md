<!-- Copilot's response, pasted by the author, saved verbatim. Model, date and exact prompt: see PROMPT_NOTE.txt -->
Add a mutation field to zombie.py and create a new src/mutation.py module. Based on the current Zombie implementation, strength, speed, and health are the natural stats to modify.

Changes to zombie.py
from dataclasses import dataclass

@dataclass
class Zombie(Agent):
    strength: int = 1
    mutation: str = "Normal"

    def __post_init__(self) -> None:
        super().__post_init__()
        self.strength = max(1, int(self.strength))


and update from_human():

return cls(
    agent_id=human.agent_id,
    agent_type="zombie",
    is_alive=True,
    x_pos=human.x_pos,
    y_pos=human.y_pos,
    health=cfg.ZOMBIE_HEALTH_RANGE[0],
    speed=human.speed,
    strength=human.weapon_tier,
    mutation="Normal",
    is_super=human.is_super,
    is_champion=human.is_champion,
)


Based on the current dataclass structure, this adds mutation tracking without affecting existing movement or combat logic.

New file: src/mutation.py
"""
Zombie mutation system.
"""

from __future__ import annotations

# Mutation spawn chances (must total <= 1.0)
BRUTE_CHANCE = 0.10
RUNNER_CHANCE = 0.10
TANK_CHANCE = 0.05


def roll_mutation(rng):
    """
    Randomly select a mutation or return None.
    """
    roll = rng.random()

    if roll < TANK_CHANCE:
        return "Tank"

    if roll < TANK_CHANCE + BRUTE_CHANCE:
        return "Brute"

    if roll < TANK_CHANCE + BRUTE_CHANCE + RUNNER_CHANCE:
        return "Runner"

    return None


def apply_mutation(zombie, name):
    """
    Apply mutation stat modifiers to a zombie instance.
    """
    if not name:
        return zombie

    zombie.mutation = name

    if name == "Brute":
        zombie.health = int(zombie.health * 1.5)
        zombie.strength += 2
        zombie.speed = max(1, zombie.speed - 1)

    elif name == "Runner":
        zombie.health = max(1, int(zombie.health * 0.75))
        zombie.strength = max(1, zombie.strength - 1)
        zombie.speed += 2

    elif name == "Tank":
        zombie.health = int(zombie.health * 3.0)
        zombie.strength += 1
        zombie.speed = max(1, zombie.speed - 2)

    return zombie

Example usage when a zombie is created
from src.mutation import roll_mutation, apply_mutation

zombie = Zombie.from_human(human)

mutation = roll_mutation(rng)
apply_mutation(zombie, mutation)


This gives you:

Mutation	Health	Strength	SpeedNormal	Base	Base	Base
Brute	+50%	+2	-1
Runner	-25%	-1	+2
Tank	+200%	+1	-2

These modifiers make each type play distinctly: Brutes hit harder, Runners chase effectively, and Tanks soak damage.
