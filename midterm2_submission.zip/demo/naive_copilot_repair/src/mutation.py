"""
Zombie mutation system.
"""

from __future__ import annotations

# Mutation spawn chances (must total <= 1.0)
BRUTE_CHANCE = 0.10
RUNNER_CHANCE = 0.10
TANK_CHANCE = 0.05


def roll_mutation(rng):
    """
    Randomly select a mutation or return None.
    """
    roll = rng.random()

    if roll < TANK_CHANCE:
        return "Tank"

    if roll < TANK_CHANCE + BRUTE_CHANCE:
        return "Brute"

    if roll < TANK_CHANCE + BRUTE_CHANCE + RUNNER_CHANCE:
        return "Runner"

    return None


def apply_mutation(zombie, name):
    """
    Apply mutation stat modifiers to a zombie instance.
    """
    if not name:
        return zombie

    zombie.mutation = name

    if name == "Brute":
        zombie.strength += 2
        zombie.speed -= 1

    elif name == "Runner":
        zombie.health -= 20
        zombie.speed += 2

    elif name == "Tank":
        zombie.health += 50
        zombie.speed -= 1

    zombie.health = max(1, int(zombie.health))
    zombie.speed = max(1, zombie.speed)
    zombie.strength = max(1, zombie.strength)

    return zombie
