# Repeat naive runs and the repair loop

Author: Mack Miracle (CPS 310 Fall 2026, Midterm #2)

## Repeat naive runs (informal prompt, five fresh runs)
Each run: a fresh AI session given only the project folder and the informal prompt in `naive_rep1/PROMPT.txt` (identical to `naive/PROMPT.txt`). No ontology, no requirements, no checker. Each was then checked with the same scripts and the same `trace.csv` as every other run. Existing suite in each: 157 passed, 13 skipped, 1 failed (the tkinter test, same as baseline).

| Run | Checks passed | Violations | What differed from the ontology | New requirements with a test |
|---|---|---|---|---|
| `naive_rep1/` | 11 | 6 | names stored in lowercase, so `apply_mutation(z, "Brute")` raises ValueError; rate 0.2 | 0 / 4 |
| `naive_rep2/` | 12 | 5 | lowercase names; Brute strength +1 (ontology +2); Runner and Tank stats; rate 0.2 | 0 / 4 |
| `naive_rep3/` | 12 | 5 | same kinds as rep2 | 0 / 4 |
| `naive_rep4/` | 12 | 5 | same kinds as rep2 (Tank health +100) | 0 / 4 |
| `naive_rep5/` | 13 | 4 | lowercase names; Brute, Runner and Tank stats; rate 0.25 correct | 0 / 4 |

Together with the first informal run (3 violations) and the blind Copilot run (5 violations), **7 of 7 informal runs violated the ontology and 0 of 7 wrote a test for the new requirements.** The violation count ranged from 3 to 6.

Caveat: lowercase mutation names are a violation only because the ontology and the prompt use "Brute", "Runner" and "Tank". The stat and rate violations stand without it (rep2 to rep5 all miss at least one stat vector, and rep1 fails outright on the capitalized name).

## Repair loop (prompt P6) on the Copilot output
`naive_copilot_repair/` holds the exercise of stage 9.
1. Input: the Copilot code from `naive_copilot/` and its checker report (5 violations).
2. `P6_prompt.txt`: the P6 template from `PIPELINE.md` Section 7, filled with the violation lines, both files, the governing ontology slice and the turned-zombie rule.
3. The prompt was executed by a fresh AI session that saw only that file. `P6_output.txt` is its one-line-per-violation answer.
4. Result: `checker_report.txt` shows **15 passed, 0 violations** (before: 12 passed, 5 violations). The existing suite is unchanged (157 passed, 13 skipped, 1 failed, the tkinter test). One repair round.
5. What the repair did not fix, because no violation named it: there are still no tests for R10-R13 (`coverage_report.txt`: 0 / 4). The loop repairs what the checker reports and nothing more, which is why the coverage gate exists as a separate control.
