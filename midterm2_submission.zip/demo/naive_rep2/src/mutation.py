"""Zombie mutations: Brute, Runner and Tank."""

from __future__ import annotations

import random

# name -> (strength multiplier, speed multiplier, health multiplier)
MUTATIONS: dict[str, tuple[float, float, float]] = {
    "brute": (1.5, 0.75, 1.0),
    "runner": (0.75, 1.5, 1.0),
    "tank": (1.0, 0.75, 2.5),
}

# Chance that a zombie is mutated at all, and relative weights per mutation.
MUTATION_CHANCE = 0.2
MUTATION_WEIGHTS: dict[str, float] = {"brute": 1.0, "runner": 1.0, "tank": 1.0}


def roll_mutation(rng: random.Random) -> str | None:
    """Return a mutation name, or None when the zombie stays normal."""
    if rng.random() >= MUTATION_CHANCE:
        return None
    names = list(MUTATION_WEIGHTS)
    return rng.choices(names, weights=[MUTATION_WEIGHTS[n] for n in names], k=1)[0]


def apply_mutation(zombie, name: str | None):
    """Apply a mutation's stat changes to ``zombie`` and record it."""
    if name is None:
        return zombie
    key = name.lower()
    if key not in MUTATIONS:
        raise ValueError(f"unknown mutation: {name!r}")
    if getattr(zombie, "mutation", None) is not None:
        raise ValueError("zombie is already mutated")
    s_mul, v_mul, h_mul = MUTATIONS[key]
    zombie.strength = max(1, round(zombie.strength * s_mul))
    zombie.speed = max(1, round(zombie.speed * v_mul))
    zombie.health = max(1, round(zombie.health * h_mul))
    zombie.mutation = key
    return zombie
