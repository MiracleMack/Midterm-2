# Demo: adding zombie mutations, four main runs plus repeats

Author: Mack Miracle (CPS 310 Fall 2026, Midterm #2)

Base code: the project snapshot of 14 Nov 2026 (not duplicated here). Each folder holds only the files that run changed or produced.

| Folder | What it is |
|---|---|
| `naive/` | informal one-sentence prompt, generated `src/mutation.py`, changed `src/zombie.py`, checker, trace and coverage reports |
| `naive_detailed/` | the same task with the approved numbers, same files |
| `naive_copilot/` | blind run: the informal prompt given by the author to Copilot in a fresh chat; `RESPONSE.md` is its full answer, applied unchanged to `src/mutation.py` and `src/zombie.py`; `copilot_response_export.docx` is a Word export of the response; `PROMPT_NOTE.txt` lists the evidence and what still needs confirming |
| `pipeline/` | `stages/` (artifact of each stage and the approval record), `prompts/` (every filled-in stage prompt, `*_prompt.txt`, and its output), generated code, derived tests |
| `naive_rep1/` to `naive_rep5/` | five repeat runs of the informal prompt from fresh sessions: generated code and reports |
| `naive_copilot_repair/` | the repair loop (P6) run on the Copilot output: prompt, output, repaired code, reports |
| `pipeline_copilot/` | independent run of pipeline stages 6 and 8 by the author with Copilot: raw replies, code, tests, reports, `RUN_NOTE.md` |
| `repeat_runs_summary.md` | results of the repeat runs and the repair loop |
| `gate_demo.txt` | transcript of `gate.py` on a throwaway file |

To reproduce a run: copy the base project, copy that folder's `src/` (and `tests/`) files over it, then from the folder holding the scripts:
```
python ontology_check.py <project-root> zombie_ontology.ttl --mutation
python trace_check.py    <project-root> zombie_ontology.ttl trace.csv
python coverage.py       <project-root> zombie_ontology.ttl trace.csv requirements.md
python -m pytest -q tests --ignore=tests/test_gui.py      # run inside the project root
```
Requires `rdflib` and `psycopg[binary]`. The one failing existing test needs tkinter and fails in every run, including the baseline.
