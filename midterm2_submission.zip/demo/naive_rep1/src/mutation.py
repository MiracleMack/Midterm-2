"""Zombie mutations: Brute, Runner and Tank."""

from __future__ import annotations

import random

MUTATION_CHANCE = 0.2

# name -> (health multiplier, speed multiplier, strength multiplier)
MUTATIONS: dict[str, tuple[float, float, float]] = {
    "brute": (1.0, 0.75, 1.5),
    "runner": (1.0, 1.5, 0.7),
    "tank": (2.5, 0.7, 1.0),
}


def roll_mutation(rng: random.Random) -> str | None:
    """Return a mutation name, or None for an ordinary zombie."""
    if rng.random() >= MUTATION_CHANCE:
        return None
    return rng.choice(sorted(MUTATIONS))


def apply_mutation(zombie, name: str | None):
    """Apply the named mutation's stat changes to ``zombie`` in place."""
    if name is None:
        return zombie
    if name not in MUTATIONS:
        raise ValueError(f"unknown mutation: {name!r}")
    health_m, speed_m, strength_m = MUTATIONS[name]
    zombie.health = max(1, round(zombie.health * health_m))
    zombie.speed = max(1, round(zombie.speed * speed_m))
    zombie.strength = max(1, round(zombie.strength * strength_m))
    zombie.mutation = name
    return zombie
