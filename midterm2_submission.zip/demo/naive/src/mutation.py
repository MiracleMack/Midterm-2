"""Zombie mutations: Brute, Runner and Tank."""

from __future__ import annotations

import random

MUTATION_CHANCE = 0.2

# name -> stat changes
MUTATIONS = {
    "Brute": {"strength": 2, "speed": -1},
    "Runner": {"speed": 2, "health": -30},
    "Tank": {"health": 60, "speed": -1},
}


def roll_mutation(rng: random.Random) -> str | None:
    """Return a mutation name, or None if this zombie is not mutated."""
    if rng.random() < MUTATION_CHANCE:
        return rng.choice(list(MUTATIONS))
    return None


def apply_mutation(zombie, name: str) -> None:
    """Apply the named mutation's stat changes to the zombie."""
    for stat, delta in MUTATIONS[name].items():
        setattr(zombie, stat, max(1, getattr(zombie, stat) + delta))
    zombie.mutation = name
