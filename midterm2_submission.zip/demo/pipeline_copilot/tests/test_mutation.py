import random
from types import SimpleNamespace

from src.mutation import apply_mutation, roll_mutation
from src.zombie import Zombie


# zs: R_Mutation
def test_roll_mutation_uses_fixed_seed_and_returns_valid_result():
    rng = random.Random(42)

    result = roll_mutation(rng)

    assert result in (None, "Brute", "Runner", "Tank")


# zs: R_Mutation
def test_brute_mutation_applies_ontology_deltas():
    zombie = SimpleNamespace(
        health=10,
        speed=5,
        strength=1,
        mutation=None,
    )

    apply_mutation(zombie, "Brute")

    assert zombie.health == 10      # deltaHealth 0
    assert zombie.speed == 4        # deltaSpeed -1
    assert zombie.strength == 3     # deltaStrength +2
    assert zombie.mutation == "Brute"


# zs: R_Mutation
def test_runner_mutation_applies_ontology_deltas():
    zombie = SimpleNamespace(
        health=100,
        speed=3,
        strength=2,
        mutation=None,
    )

    apply_mutation(zombie, "Runner")

    assert zombie.health == 80      # deltaHealth -20
    assert zombie.speed == 5        # deltaSpeed +2
    assert zombie.strength == 2     # deltaStrength 0
    assert zombie.mutation == "Runner"


# zs: R_Mutation
def test_tank_mutation_applies_ontology_deltas():
    zombie = SimpleNamespace(
        health=100,
        speed=4,
        strength=2,
        mutation=None,
    )

    apply_mutation(zombie, "Tank")

    assert zombie.health == 150     # deltaHealth +50
    assert zombie.speed == 3        # deltaSpeed -1
    assert zombie.strength == 2     # deltaStrength 0
    assert zombie.mutation == "Tank"


# zs: R_Mutation
def test_stats_are_clamped_to_min_stat_boundary_value_one():
    zombie = SimpleNamespace(
        health=1,
        speed=1,
        strength=1,
        mutation=None,
    )

    apply_mutation(zombie, "Runner")

    assert zombie.health == 1
    assert zombie.speed == 3
    assert zombie.strength == 1


# zs: R_Mutation
def test_none_mutation_records_none():
    zombie = SimpleNamespace(
        health=10,
        speed=10,
        strength=10,
        mutation="Brute",
    )

    apply_mutation(zombie, None)

    assert zombie.health == 10
    assert zombie.speed == 10
    assert zombie.strength == 10
    assert zombie.mutation is None


# zs: mutationTarget
def test_zombie_has_mutation_attribute_default_none():
    zombie = Zombie(
        agent_id=1,
        agent_type="zombie",
        is_alive=True,
        x_pos=0,
        y_pos=0,
        health=10,
        speed=1,
    )

    assert hasattr(zombie, "mutation")
    assert zombie.mutation is None


# zs: R_Mutation
def test_turned_zombie_has_no_mutation():
    human = SimpleNamespace(
        agent_id=7,
        x_pos=1,
        y_pos=2,
        speed=3,
        weapon_tier=4,
        is_super=False,
        is_champion=False,
    )

    zombie = Zombie.from_human(human)

    assert zombie.mutation is None
