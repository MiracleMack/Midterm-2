# Independent pipeline run: Copilot executing stages 6 and 8 (P4, P5)

Author: Mack Miracle (CPS 310 Fall 2026, Midterm #2)

The author, not the assistant that built the pipeline, gave the saved pipeline prompts to web Copilot Chat (Basic) and applied the replies. The approved ontology (`zombie_ontology.ttl`, stage 2) and requirements were used unchanged; stages 1 to 5 were not redone.

| Step | Prompt (`demo/pipeline/prompts/`) | Raw reply (`responses/`) | Applied as |
|---|---|---|---|
| Stage 6, mutation module | `P4_mutation_prompt.txt` | `P4_mutation_response.txt` | `src/mutation.py`; the one prose sentence at the top of the reply was removed, the code is unchanged |
| Stage 6, Zombie attribute | `P4_zombie_prompt.txt` | `P4_zombie_response.txt` | `src/zombie.py`, unchanged |
| Stage 8, tests | `P5_prompt.txt` | `P5_response.txt` | `tests/test_mutation.py`, unchanged |

All three prompts were given to Copilot as uploaded files, not pasted text (confirmed by the author; Copilot's reply to the first says so).

## Results (same scripts, same trace.csv, same base project as every other run)
| Check | Result |
|---|---|
| `ontology_check.py --mutation` | **15 passed, 0 violations** (`checker_report.txt`) |
| existing suite plus new tests | 165 passed, 13 skipped, 1 failed (the tkinter test, as in every run); baseline 157 plus 8 new (`test_report.txt`) |
| `trace_check.py` | 0 failures (`trace_report.txt`) |
| `coverage.py` | new requirements R10-R13: 4/4 with a test; all 14: 12/14 (R2, R3 are known debt) (`coverage_report.txt`) |
| repair rounds | 0 |

For comparison, the same Copilot given the informal prompt with no ontology (`demo/naive_copilot/`) had 5 violations and 0/4 new requirements with a test.

## Findings that count against the pipeline
1. **Coverage is shallow.** `coverage.py` counts a requirement as tested when a test file named in `trace.csv` exists. Copilot's 8 tests do not check the 0.25 mutation rate, "at most one mutation", or that a seeded generator gives the same result twice; its roll test only checks the result is one of four values. The pipeline's own nine tests are stricter. The 4/4 figure therefore shows that tests exist, not that they are thorough. The checker (`ontology_check.py`) covers the rate and determinism independently, which is why the two controls are kept separate.
2. **A stale term slipped through the trace check.** One test is tagged `# zs: mutationTarget`. That term was in the ontology slice inside the saved `P5_prompt.txt`, and was removed from the ontology afterwards in the cleanup of unused terms. `trace_check.py` only validates tags that name rules (`R_...`), so a tag naming any other ontology term is not checked and the run shows 0 trace failures. This is a gap in the script. It was left unchanged so that this run's result is reported as it happened; extending the check to every `# zs:` tag is an obvious improvement.
