from random import Random

# Mutation definitions from the ontology slice
MUTATIONS = {
    "Brute": {
        "delta_health": 0,
        "delta_speed": -1,
        "delta_strength": 2,
    },
    "Runner": {
        "delta_health": -20,
        "delta_speed": 2,
        "delta_strength": 0,
    },
    "Tank": {
        "delta_health": 50,
        "delta_speed": -1,
        "delta_strength": 0,
    },
}

MUTATION_CHANCE = 0.25
MIN_STAT = 1


def roll_mutation(rng: Random):
    # zs: R_Mutation
    if rng.random() >= MUTATION_CHANCE:
        return None

    return rng.choice(list(MUTATIONS.keys()))


def apply_mutation(zombie, name):
    # zs: R_Mutation
    if name is None:
        zombie.mutation = None
        return

    mutation = MUTATIONS[name]

    zombie.health += mutation["delta_health"]
    zombie.speed += mutation["delta_speed"]
    zombie.strength += mutation["delta_strength"]

    zombie.health = max(MIN_STAT, zombie.health)
    zombie.speed = max(MIN_STAT, zombie.speed)
    zombie.strength = max(MIN_STAT, zombie.strength)

    zombie.mutation = name
