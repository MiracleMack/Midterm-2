"""Zombie mutations: Brute, Runner and Tank stat modifiers."""

from __future__ import annotations

import random

# name -> (strength multiplier, speed multiplier, health multiplier)
MUTATIONS: dict[str, tuple[float, float, float]] = {
    "brute": (1.5, 0.7, 1.0),   # stronger but slower
    "runner": (0.7, 1.5, 1.0),  # faster but weaker
    "tank": (1.0, 0.7, 2.5),    # lots more health but slower
}

# Chance that a zombie is mutated at all, and relative weights when it is.
MUTATION_CHANCE = 0.25
MUTATION_WEIGHTS: dict[str, int] = {"brute": 1, "runner": 1, "tank": 1}


def roll_mutation(rng: random.Random) -> str | None:
    """Return a mutation name, or ``None`` if the zombie stays normal."""
    if rng.random() >= MUTATION_CHANCE:
        return None
    names = list(MUTATION_WEIGHTS)
    return rng.choices(names, weights=[MUTATION_WEIGHTS[n] for n in names])[0]


def apply_mutation(zombie, name: str | None):
    """Apply the named mutation's stat changes to ``zombie`` and return it."""
    if name is None:
        zombie.mutation = None
        return zombie
    key = name.lower()
    if key not in MUTATIONS:
        raise ValueError(f"unknown mutation: {name!r}")
    if getattr(zombie, "mutation", None) is not None:
        raise ValueError("zombie is already mutated")
    s_mul, v_mul, h_mul = MUTATIONS[key]
    zombie.strength = max(1, round(zombie.strength * s_mul))
    zombie.speed = max(1, round(zombie.speed * v_mul))
    zombie.health = max(1, round(zombie.health * h_mul))
    zombie.mutation = key
    return zombie
