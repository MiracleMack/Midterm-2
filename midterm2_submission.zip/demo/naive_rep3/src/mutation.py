"""Zombie mutations: Brute, Runner and Tank stat modifiers."""

from __future__ import annotations

import random

# name -> (health multiplier, speed multiplier, strength multiplier)
MUTATIONS: dict[str, tuple[float, float, float]] = {
    "brute": (1.0, 0.7, 1.5),
    "runner": (1.0, 1.5, 0.7),
    "tank": (2.5, 0.7, 1.0),
}

MUTATION_CHANCE = 0.2


def roll_mutation(rng: random.Random) -> str | None:
    """Return a mutation name, or None when the zombie stays normal."""
    if rng.random() >= MUTATION_CHANCE:
        return None
    return rng.choice(sorted(MUTATIONS))


def apply_mutation(zombie, name: str | None) -> None:
    """Apply a named mutation's stat changes to ``zombie`` in place."""
    if name is None:
        zombie.mutation = None
        return
    key = name.lower()
    if key not in MUTATIONS:
        raise ValueError(f"unknown mutation: {name!r}")
    health_m, speed_m, strength_m = MUTATIONS[key]
    zombie.health = max(1, round(zombie.health * health_m))
    zombie.speed = max(1, round(zombie.speed * speed_m))
    zombie.strength = max(1, round(zombie.strength * strength_m))
    zombie.mutation = key
