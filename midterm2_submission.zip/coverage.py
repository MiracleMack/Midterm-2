"""Coverage metrics (pipeline stages 5, 6, 8).
Author: Mack Miracle (CPS 310 Fall 2026, Midterm #2)

Usage: python coverage.py <project-root> <ontology.ttl> <trace.csv> <requirements.md>

Reports the percentage of requirements with an ontology term, a code file and a test, and which
ontology rules carry a '# zs:' tag in code and in tests. Requirements marked N (new) in
requirements.md must reach 100% on all three; requirements marked E (existing) are reported, and
gaps there are listed as known debt. Exit 1 if a new requirement is below 100%.
"""
import re, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from trace_check import load, split, scan_tags


def statuses(req_md):
    out = {}
    for line in Path(req_md).read_text().splitlines():
        m = re.match(r"\|\s*(R\d+)\s*\|\s*([EN])\s*\|", line)
        if m:
            out[m.group(1)] = m.group(2)
    return out


def pct(n, d):
    return 100.0 * n / d if d else 100.0


def main():
    root, onto, trace, reqs = Path(sys.argv[1]).resolve(), Path(sys.argv[2]), Path(sys.argv[3]), sys.argv[4]
    g, rules, terms, rows = load(root, onto, trace)
    st = statuses(reqs)
    def has(r, col):
        files = split(r[col]) if col != "ontology_terms" else split(r[col])
        if col == "ontology_terms":
            return bool(files) and all(t in terms for t in files)
        return bool(files) and all((root / f).exists() for f in files)
    cols = [("ontology term", "ontology_terms"), ("code", "code"), ("test", "tests")]
    fail = False
    for label, subset in (("ALL requirements", [r["requirement"] for r in rows]),
                          ("NEW requirements (N)", [r["requirement"] for r in rows if st.get(r["requirement"]) == "N"])):
        sub = [r for r in rows if r["requirement"] in subset]
        print(f"{label} ({len(sub)}):")
        for name, col in cols:
            n = sum(has(r, col) for r in sub)
            print(f"  with {name:13s}: {n}/{len(sub)} = {pct(n, len(sub)):.0f}%")
            missing = [r["requirement"] for r in sub if not has(r, col)]
            if missing:
                print(f"     missing: {', '.join(missing)}")
            if label.startswith("NEW") and n != len(sub):
                fail = True
    tags = scan_tags(root)
    print(f"Rules tagged '# zs:' in code or tests: {len(set(tags) & rules)}/{len(rules)}")
    if fail:
        print("\nFAIL: a new requirement is missing a term, code or test")
    sys.exit(1 if fail else 0)


if __name__ == "__main__":
    main()
